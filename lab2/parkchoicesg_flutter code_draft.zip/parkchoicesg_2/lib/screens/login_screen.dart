import 'package:flutter/material.dart';
import 'package:parkchoicesg_2/screens/carpark_search_screen.dart';
import 'register_screen.dart';

/// ParkChoiceSG Login Screen
/// Drop this widget into a MaterialApp's `home` or push it via Navigator.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController(text: 'driver@parksmart.io');
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;

  static const _bgColor = Color(0xFF0B0B0F);
  static const _fieldColor = Color(0xFF1B1C22);
  static const _accentColor = Color(0xFF22E1EE);
  static const _mutedTextColor = Color(0xFF8A8D98);

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgColor,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 40),
              _buildLogo(),
              const SizedBox(height: 60),
              const Text(
                'Log In',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Enter your email and password to continue.',
                style: TextStyle(color: _mutedTextColor, fontSize: 14),
              ),
              const SizedBox(height: 28),
              _buildLabel('EMAIL ADDRESS'),
              const SizedBox(height: 8),
              _buildTextField(
                controller: _emailController,
                icon: Icons.mail_outline,
                hintText: 'Email address',
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 20),
              _buildLabel('PASSWORD'),
              const SizedBox(height: 8),
              _buildTextField(
                controller: _passwordController,
                icon: Icons.lock_outline,
                hintText: 'Password',
                obscureText: _obscurePassword,
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscurePassword
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                    color: _mutedTextColor,
                  ),
                  onPressed: () {
                    setState(() => _obscurePassword = !_obscurePassword);
                  },
                ),
              ),
              const SizedBox(height: 28),
              _buildSignInButton(),
              const SizedBox(height: 20),
              Center(
                child: _buildRichRow(
                  leading: 'Forgot Password? ',
                  action: 'Reset here',
                  onTap: () {
                    // TODO: navigate to password reset flow
                  },
                ),
              ),
              const SizedBox(height: 40),
              Center(
                child: _buildRichRow(
                  leading: "Don't have an account? ",
                  action: 'Register',
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const RegisterScreen(),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLogo() {
    return Center(
      child: Column(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _accentColor, width: 2),
            ),
            child: const Icon(
              Icons.close_rounded,
              color: _accentColor,
              size: 28,
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'ParkChoiceSG',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLabel(String text) {
    return Text(
      text,
      style: const TextStyle(
        color: _mutedTextColor,
        fontSize: 12,
        fontWeight: FontWeight.w600,
        letterSpacing: 0.5,
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required IconData icon,
    required String hintText,
    TextInputType keyboardType = TextInputType.text,
    bool obscureText = false,
    Widget? suffixIcon,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _fieldColor,
        borderRadius: BorderRadius.circular(14),
      ),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        obscureText: obscureText,
        style: const TextStyle(color: Colors.white, fontSize: 15),
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: _mutedTextColor, size: 20),
          suffixIcon: suffixIcon,
          hintText: hintText,
          hintStyle: const TextStyle(color: _mutedTextColor),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 16),
        ),
      ),
    );
  }

  Widget _buildSignInButton() {
    return SizedBox(
      width: double.infinity,
      height: 54,
      child: ElevatedButton(
        onPressed: () {
          // TODO: handle sign in

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const CarparkSearchScreen(),
            ),
          );
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: _accentColor,
          foregroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          elevation: 0,
        ),
        child: const Text(
          'Sign In',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }

  Widget _buildRichRow({
    required String leading,
    required String action,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: RichText(
        text: TextSpan(
          style: const TextStyle(fontSize: 14, color: _mutedTextColor),
          children: [
            TextSpan(text: leading),
            TextSpan(
              text: action,
              style: const TextStyle(
                color: _accentColor,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}