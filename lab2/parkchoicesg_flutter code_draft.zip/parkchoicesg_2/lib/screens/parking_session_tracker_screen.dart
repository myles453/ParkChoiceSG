import 'dart:async';
import 'package:flutter/material.dart';
import '../services/parking_session_manager.dart';
import 'admin_panel_screen.dart';
import 'carpark_search_screen.dart';
import 'preferences_screen.dart';

/// ParkChoiceSG Active Session / Parking Session Tracker Screen
/// Drop this widget into a MaterialApp's `home` or push it via Navigator.
class ParkingSessionTrackerScreen extends StatefulWidget {
  const ParkingSessionTrackerScreen({super.key});

  @override
  State<ParkingSessionTrackerScreen> createState() =>
      _ParkingSessionTrackerScreenState();
}

class _RecentSessionModel {
  final String name;
  final String location;
  final String dateLabel;
  final String cost;
  final String duration;

  const _RecentSessionModel({
    required this.name,
    required this.location,
    required this.dateLabel,
    required this.cost,
    required this.duration,
  });
}

class _MonthlySessionGroup {
  final String monthYear;
  final String totalExpenditure;
  final List<_RecentSessionModel> sessions;

  const _MonthlySessionGroup({
    required this.monthYear,
    required this.totalExpenditure,
    required this.sessions,
  });
}

class _ParkingSessionTrackerScreenState
    extends State<ParkingSessionTrackerScreen>
    with SingleTickerProviderStateMixin {
  static const _bgColor = Color(0xFF0B0B0F);
  static const _cardColor = Color(0xFF16171D);
  static const _pillColor = Color(0xFF1F2027);
  static const _accentColor = Color(0xFF22E1EE);
  static const _mutedTextColor = Color(0xFF8A8D98);
  static const _orangeColor = Color(0xFFF5A623);

  final int _selectedNavIndex = 1;
  Timer? _timer;
  late AnimationController _blinkingController;

  // FR-6.6 Monthly Session History Aggregation Groups
  final List<_MonthlySessionGroup> _monthlyGroups = [
    _MonthlySessionGroup(
      monthYear: 'October 2026',
      totalExpenditure: '\$42.10',
      sessions: [
        const _RecentSessionModel(
          name: 'Suntec Plaza Level B2',
          location: 'Level B2, Lot 08',
          dateLabel: 'Yesterday, 2:15 PM',
          cost: '\$15.00',
          duration: '3h 0m',
        ),
        const _RecentSessionModel(
          name: 'Orchard Central Terminal',
          location: 'Level 3, Lot B12',
          dateLabel: '14 Oct, 11:30 AM',
          cost: '\$9.00',
          duration: '2h 0m',
        ),
        const _RecentSessionModel(
          name: 'Somerset Underground',
          location: 'Level 1, Lot A04',
          dateLabel: '11 Oct, 09:15 AM',
          cost: '\$5.70',
          duration: '1h 30m',
        ),
        const _RecentSessionModel(
          name: 'National Museum Park',
          location: 'Level 2, Lot C09',
          dateLabel: '08 Oct, 03:00 PM',
          cost: '\$12.40',
          duration: '4h 10m',
        ),
      ],
    ),
    _MonthlySessionGroup(
      monthYear: 'September 2026',
      totalExpenditure: '\$28.50',
      sessions: [
        const _RecentSessionModel(
          name: 'Bugis Junction Level 1',
          location: 'Level 1, Lot 42',
          dateLabel: '28 Sep, 04:20 PM',
          cost: '\$14.50',
          duration: '3h 30m',
        ),
        const _RecentSessionModel(
          name: 'Marina Bay Sands Lot B',
          location: 'Basement 2, Lot 105',
          dateLabel: '19 Sep, 01:10 PM',
          cost: '\$14.00',
          duration: '2h 45m',
        ),
      ],
    ),
  ];

  @override
  void initState() {
    super.initState();
    ParkingSessionManager.instance.addListener(_onSessionChanged);
    _blinkingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    _startTimerIfNeeded();
  }

  void _startTimerIfNeeded() {
    _timer?.cancel();
    if (ParkingSessionManager.instance.hasActiveSession) {
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) {
          setState(() {});
        }
      });
    }
  }

  void _onSessionChanged() {
    _startTimerIfNeeded();
    if (mounted) {
      setState(() {});
    }
  }

  @override
  void dispose() {
    ParkingSessionManager.instance.removeListener(_onSessionChanged);
    _blinkingController.dispose();
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgColor,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(),
                  const SizedBox(height: 20),
                  _buildActiveSessionCard(),
                  const SizedBox(height: 24),
                  const Text(
                    'Session History & Aggregation',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                itemCount: _monthlyGroups.length,
                itemBuilder: (context, groupIndex) {
                  final group = _monthlyGroups[groupIndex];
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // FR-6.6 Monthly Expenditure Aggregation Header
                      _buildMonthlyHeader(group),
                      ...group.sessions.map((s) => Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: _buildRecentSessionTile(s),
                          )),
                    ],
                  );
                },
              ),
            ),
            _buildBottomNavBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Active Session',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 4),
              Text(
                'Track real-time duration & costs',
                style: TextStyle(color: _mutedTextColor, fontSize: 14),
              ),
            ],
          ),
        ),
        Container(
          width: 40,
          height: 40,
          decoration: const BoxDecoration(
            color: Color(0xFF1C2A33),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.person_outline, color: _accentColor, size: 20),
        ),
      ],
    );
  }

  Widget _buildActiveSessionCard() {
    final session = ParkingSessionManager.instance.currentSession;
    if (session == null) {
      return _buildNoActiveSessionCard();
    }

    final durationStr = _formatDuration(session.duration);
    final runningCostStr = '\$${session.runningCost.toStringAsFixed(2)}';
    final ratePer30Min =
        '\$${(session.hourlyRate / 2).toStringAsFixed(2)} / 30 min';

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _accentColor, width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      session.carparkName,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      session.location,
                      style: const TextStyle(color: _mutedTextColor, fontSize: 13),
                    ),
                  ],
                ),
              ),
              FadeTransition(
                opacity: Tween<double>(begin: 0.2, end: 1.0).animate(
                  CurvedAnimation(
                    parent: _blinkingController,
                    curve: Curves.easeInOut,
                  ),
                ),
                child: Container(
                  width: 10,
                  height: 10,
                  margin: const EdgeInsets.only(top: 4),
                  decoration: const BoxDecoration(
                    color: _accentColor,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: _buildStatPill(
                  label: 'PARKED DURATION',
                  value: durationStr,
                  valueColor: Colors.white,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildStatPill(
                  label: 'RUNNING COST',
                  value: runningCostStr,
                  valueColor: _accentColor,
                  subtitle: ratePer30Min,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // FR-6.8 Extend Session Quick Chips / Action Row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: const [
              Text(
                'Reminder Notice',
                style: TextStyle(color: _mutedTextColor, fontSize: 12),
              ),
              Text(
                'Alert Active',
                style: TextStyle(color: _accentColor, fontSize: 12, fontWeight: FontWeight.w500),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // Actions: End Session (Amber) + Extend (Secondary)
          Row(
            children: [
              Expanded(
                flex: 3,
                child: SizedBox(
                  height: 48,
                  child: ElevatedButton.icon(
                    onPressed: _onEndSessionPrompt, // FR-6.5 Confirmation Modal
                    icon: const Icon(Icons.stop_rounded, color: Colors.black, size: 18),
                    label: const Text(
                      'End Session',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _orangeColor,
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 0,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: SizedBox(
                  height: 48,
                  child: OutlinedButton.icon(
                    onPressed: _showExtendSessionModal, // FR-6.8 Extend Session
                    icon: const Icon(Icons.add_alarm, size: 16, color: _accentColor),
                    label: const Text(
                      'Extend',
                      style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
                    ),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFF2A2C34)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNoActiveSessionCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF2A2C34), width: 1),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Icon(
            Icons.local_parking_rounded,
            color: _mutedTextColor,
            size: 40,
          ),
          SizedBox(height: 12),
          Text(
            'No active sessions',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 4),
          Text(
            'Start a parking session from search',
            style: TextStyle(
              color: _mutedTextColor,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  // Standard 13 & FR-6.5 End Session Confirmation Modal Prompt
  void _onEndSessionPrompt() {
    final session = ParkingSessionManager.instance.currentSession;
    if (session == null) return;

    final durationStr = _formatDuration(session.duration);
    final finalCostStr = '\$${session.runningCost.toStringAsFixed(2)}';

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: Color(0xFF2A2C34)),
        ),
        title: const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: _orangeColor, size: 24),
            SizedBox(width: 8),
            Text(
              'End Parking Session?',
              style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Confirming will calculate final charges and record this session to your monthly history.',
              style: TextStyle(color: _mutedTextColor, fontSize: 13),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _pillColor,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white10),
              ),
              child: Column(
                children: [
                  _buildConfirmRow('Carpark', session.carparkName, isHighlight: true),
                  const SizedBox(height: 8),
                  _buildConfirmRow('Final Duration', durationStr, isHighlight: false),
                  const SizedBox(height: 8),
                  _buildConfirmRow('Computed Total', finalCostStr, isHighlight: true, valueColor: _accentColor),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: _mutedTextColor)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              _confirmAndEndSession();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _orangeColor,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text('Confirm End Session', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _buildConfirmRow(String label, String value, {bool isHighlight = false, Color? valueColor}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(color: _mutedTextColor, fontSize: 12),
        ),
        Text(
          value,
          style: TextStyle(
            color: valueColor ?? (isHighlight ? Colors.white : Colors.white70),
            fontSize: isHighlight ? 13 : 12,
            fontWeight: isHighlight ? FontWeight.bold : FontWeight.w500,
          ),
        ),
      ],
    );
  }

  void _confirmAndEndSession() {
    final session = ParkingSessionManager.instance.currentSession;
    if (session != null) {
      final endedModel = _RecentSessionModel(
        name: session.carparkName,
        location: session.location,
        dateLabel: 'Just now',
        cost: '\$${session.runningCost.toStringAsFixed(2)}',
        duration: _formatDuration(session.duration),
      );
      if (_monthlyGroups.isNotEmpty) {
        final currentGroup = _monthlyGroups[0];
        final updatedList = List<_RecentSessionModel>.from(currentGroup.sessions)
          ..insert(0, endedModel);
        _monthlyGroups[0] = _MonthlySessionGroup(
          monthYear: currentGroup.monthYear,
          totalExpenditure: currentGroup.totalExpenditure,
          sessions: updatedList,
        );
      }
    }
    ParkingSessionManager.instance.endSession();
  }

  // FR-6.8 Extend Session Modal
  void _showExtendSessionModal() {
    String selectedInterval = '+30 min';
    showModalBottomSheet(
      context: context,
      backgroundColor: _cardColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Extend Session & Reminder',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, color: _mutedTextColor),
                        onPressed: () => Navigator.pop(ctx),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Select an interval to extend your session duration and adjust reminder alerts:',
                    style: TextStyle(color: _mutedTextColor, fontSize: 13),
                  ),
                  const SizedBox(height: 20),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: ['+15 min', '+30 min', '+45 min', '+1 hour', '+2 hours'].map((interval) {
                      final isSelected = selectedInterval == interval;
                      return ChoiceChip(
                        label: Text(interval),
                        selected: isSelected,
                        selectedColor: _accentColor,
                        backgroundColor: _pillColor,
                        side: BorderSide(
                          color: isSelected ? _accentColor : const Color(0xFF2A2C34),
                        ),
                        labelStyle: TextStyle(
                          color: isSelected ? Colors.black : Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                        onSelected: (selected) {
                          if (selected) {
                            setModalState(() {
                              selectedInterval = interval;
                            });
                          }
                        },
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton.icon(
                      onPressed: () {
                        Navigator.pop(ctx);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Session extended by $selectedInterval. Reminder alert updated.'),
                            backgroundColor: _accentColor,
                            duration: const Duration(seconds: 2),
                          ),
                        );
                      },
                      icon: const Icon(Icons.check_circle_outline, color: Colors.black, size: 18),
                      label: const Text(
                        'Apply Extension',
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.black),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _accentColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // FR-6.6 Monthly Expenditure Aggregation Header Tile
  Widget _buildMonthlyHeader(_MonthlySessionGroup group) {
    return Container(
      margin: const EdgeInsets.only(top: 14, bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF14151C),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF252733)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              const Icon(Icons.calendar_month_outlined, color: _accentColor, size: 16),
              const SizedBox(width: 8),
              Text(
                group.monthYear,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                '(${group.sessions.length} sessions)',
                style: const TextStyle(color: _mutedTextColor, fontSize: 12),
              ),
            ],
          ),
          Row(
            children: [
              const Text(
                'Total: ',
                style: TextStyle(color: _mutedTextColor, fontSize: 13),
              ),
              Text(
                group.totalExpenditure,
                style: const TextStyle(
                  color: _accentColor,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _formatDuration(Duration duration) {
    final hours = duration.inHours.toString().padLeft(2, '0');
    final minutes = (duration.inMinutes % 60).toString().padLeft(2, '0');
    final seconds = (duration.inSeconds % 60).toString().padLeft(2, '0');
    return '$hours:$minutes:$seconds';
  }

  Widget _buildStatPill({
    required String label,
    required String value,
    required Color valueColor,
    String? subtitle,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _pillColor,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: _mutedTextColor,
              fontSize: 10,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.4,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              color: valueColor,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 2),
            Text(
              subtitle,
              style: const TextStyle(color: _mutedTextColor, fontSize: 11),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildRecentSessionTile(_RecentSessionModel session) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: _pillColor,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.history, color: _mutedTextColor, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  session.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  session.location,
                  style: const TextStyle(color: _mutedTextColor, fontSize: 12),
                ),
                const SizedBox(height: 2),
                Text(
                  session.dateLabel,
                  style: const TextStyle(color: _mutedTextColor, fontSize: 12),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                session.cost,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                session.duration,
                style: const TextStyle(color: _mutedTextColor, fontSize: 12),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _onNavTap(int index) {
    if (index == _selectedNavIndex) return;
    Widget destination;
    switch (index) {
      case 0:
        destination = const CarparkSearchScreen();
        break;
      case 1:
        destination = const ParkingSessionTrackerScreen();
        break;
      case 2:
        destination = const PreferencesScreen();
        break;
      case 3:
        destination = const AdminPanelScreen();
        break;
      default:
        return;
    }
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation1, animation2) => destination,
        transitionDuration: Duration.zero,
        reverseTransitionDuration: Duration.zero,
      ),
    );
  }

  Widget _buildBottomNavBar() {
    final items = [
      (icon: Icons.search, label: 'Search'),
      (icon: Icons.show_chart, label: 'Tracker'),
      (icon: Icons.tune, label: 'Preferences'),
      (icon: Icons.chevron_right, label: 'Admin'),
    ];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        color: Color(0xFF0F1013),
        border: Border(top: BorderSide(color: Color(0xFF1E2027), width: 1)),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(items.length, (index) {
            final item = items[index];
            final isSelected = index == _selectedNavIndex;
            final color = isSelected ? _accentColor : _mutedTextColor;
            return InkWell(
              onTap: () => _onNavTap(index),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(item.icon, color: color, size: 22),
                  const SizedBox(height: 4),
                  Text(
                    item.label,
                    style: TextStyle(color: color, fontSize: 11),
                  ),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}
