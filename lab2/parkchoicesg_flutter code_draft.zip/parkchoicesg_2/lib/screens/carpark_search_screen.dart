import 'package:flutter/material.dart';
import '../services/parking_session_manager.dart';
import 'admin_panel_screen.dart';
import 'parking_session_tracker_screen.dart';
import 'preferences_screen.dart';

/// ParkChoiceSG Find Parking / Carpark Search Screen
/// Drop this widget into a MaterialApp's `home` or push it via Navigator.
class CarparkSearchScreen extends StatefulWidget {
  const CarparkSearchScreen({super.key});

  @override
  State<CarparkSearchScreen> createState() => _CarparkSearchScreenState();
}

class _CarparkModel {
  final String name;
  final String driveTime;
  final String pricePerHour;
  final int spotsLeft;
  final int spotsTotal;
  final int rank;
  final String walkTime;
  final String confidenceLevel;
  final String confidenceText;

  const _CarparkModel({
    required this.name,
    required this.driveTime,
    required this.pricePerHour,
    required this.spotsLeft,
    required this.spotsTotal,
    required this.rank,
    required this.walkTime,
    required this.confidenceLevel,
    required this.confidenceText,
  });
}

class _CarparkSearchScreenState extends State<CarparkSearchScreen>
    with SingleTickerProviderStateMixin {
  final _searchController =
      TextEditingController(text: 'Orchard Road Mall District, SG');

  String _stayDuration = '2 Hours stay';
  String _eta = 'ETA: 10:15 AM';
  String _sortBy = 'Sort: Best Match';
  String _filterFeature = 'Filter: All Carparks';
  final int _selectedNavIndex = 0;
  bool _isMapView = false;
  late AnimationController _blinkingController;

  static const _bgColor = Color(0xFF0B0B0F);
  static const _cardColor = Color(0xFF16171D);
  static const _fieldColor = Color(0xFF1B1C22);
  static const _accentColor = Color(0xFF22E1EE);
  static const _mutedTextColor = Color(0xFF8A8D98);
  static const _greenColor = Color(0xFF4ADE80);
  static const _amberColor = Color(0xFFF59E0B);

  final List<_CarparkModel> _carparks = const [
    _CarparkModel(
      name: 'Orchard Central Terminal',
      driveTime: '12m drive',
      pricePerHour: '\$4.50/hr',
      spotsLeft: 48,
      spotsTotal: 320,
      rank: 1,
      walkTime: '5 min walk',
      confidenceLevel: 'High',
      confidenceText: 'High Confidence',
    ),
    _CarparkModel(
      name: 'Suntec Plaza Level B2',
      driveTime: '8m drive',
      pricePerHour: '\$5.00/hr',
      spotsLeft: 12,
      spotsTotal: 450,
      rank: 2,
      walkTime: '6 min walk',
      confidenceLevel: 'Medium',
      confidenceText: 'Med Confidence',
    ),
    _CarparkModel(
      name: 'Somerset Underground',
      driveTime: '15m drive',
      pricePerHour: '\$3.80/hr',
      spotsLeft: 142,
      spotsTotal: 200,
      rank: 3,
      walkTime: '8 min walk',
      confidenceLevel: 'High',
      confidenceText: 'High Confidence',
    ),
    _CarparkModel(
      name: 'Marina Square Basement',
      driveTime: '10m drive',
      pricePerHour: '\$4.00/hr',
      spotsLeft: 85,
      spotsTotal: 500,
      rank: 4,
      walkTime: '7 min walk',
      confidenceLevel: 'High',
      confidenceText: 'High Confidence',
    ),
    _CarparkModel(
      name: 'Ngee Ann City Tower B',
      driveTime: '14m drive',
      pricePerHour: '\$5.50/hr',
      spotsLeft: 5,
      spotsTotal: 280,
      rank: 5,
      walkTime: '4 min walk',
      confidenceLevel: 'Low',
      confidenceText: 'Low Confidence',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _blinkingController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _blinkingController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgColor,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildHeader(),
                  const SizedBox(height: 20),
                  _buildSearchBar(),
                  const SizedBox(height: 12),
                  _buildFilterRow(),
                  const SizedBox(height: 24),
                  _buildRecommendationsHeader(),
                ],
              ),
            ),
            Expanded(
              child: _isMapView
                  ? _buildMapViewPlaceholder()
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                      itemCount: _carparks.length,
                      itemBuilder: (context, index) {
                        final cp = _carparks[index];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 16),
                          child: _buildCarparkCard(cp),
                        );
                      },
                    ),
            ),
            _buildBottomNavBar(),
          ],
        ),
      ),
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(bottom: 60),
        child: FloatingActionButton.extended(
          onPressed: () {
            setState(() {
              _isMapView = !_isMapView;
            });
          },
          backgroundColor: _fieldColor,
          foregroundColor: _accentColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
            side: const BorderSide(color: Color(0xFF2A2C34)),
          ),
          icon: Icon(_isMapView ? Icons.format_list_bulleted : Icons.map_outlined, size: 18),
          label: Text(
            _isMapView ? 'List View' : 'Map View',
            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Find Parking',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 4),
              Text(
                'Where are you heading today?',
                style: TextStyle(color: _mutedTextColor, fontSize: 14),
              ),
            ],
          ),
        ),
        Container(
          width: 40,
          height: 40,
          decoration: const BoxDecoration(
            color: Color(0xFF1C2A33),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.person_outline, color: _accentColor, size: 20),
        ),
      ],
    );
  }

  Widget _buildSearchBar() {
    return Container(
      decoration: BoxDecoration(
        color: _fieldColor,
        borderRadius: BorderRadius.circular(14),
      ),
      child: TextField(
        controller: _searchController,
        style: const TextStyle(color: Colors.white, fontSize: 15),
        decoration: const InputDecoration(
          prefixIcon: Icon(Icons.search, color: _accentColor),
          suffixIcon: Icon(Icons.cancel, color: _mutedTextColor, size: 20),
          border: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(vertical: 16),
        ),
      ),
    );
  }

  Widget _buildFilterRow() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _buildDropdownChip(
                icon: Icons.access_time,
                label: _stayDuration,
                onTap: _showStayDurationPicker,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildDropdownChip(
                icon: Icons.navigation_outlined,
                label: _eta,
                onTap: _showEtaPicker,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _buildDropdownChip(
                icon: Icons.swap_vert,
                label: _sortBy,
                onTap: _showSortByPicker,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildDropdownChip(
                icon: Icons.tune,
                label: _filterFeature,
                onTap: _showFeatureFilterPicker,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildDropdownChip({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: _fieldColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF262833)),
        ),
        child: Row(
          children: [
            Icon(icon, color: _accentColor, size: 16),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                label,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w500),
              ),
            ),
            const Icon(Icons.keyboard_arrow_down,
                color: _mutedTextColor, size: 18),
          ],
        ),
      ),
    );
  }

  void _showStayDurationPicker() {
    _showOptionsPickerModal(
      title: 'Select Stay Duration',
      currentSelection: _stayDuration,
      options: const [
        '30 Mins stay',
        '1 Hour stay',
        '2 Hours stay',
        '3 Hours stay',
        '4 Hours stay',
        'Half Day stay',
        'Full Day stay',
      ],
      onSelected: (val) => setState(() => _stayDuration = val),
    );
  }

  void _showEtaPicker() {
    _showOptionsPickerModal(
      title: 'Select Estimated Arrival (ETA)',
      currentSelection: _eta,
      options: const [
        'Arriving Now',
        'ETA: In 15 Mins',
        'ETA: In 30 Mins',
        'ETA: 10:15 AM',
        'ETA: 11:30 AM',
        'ETA: 2:00 PM',
        'ETA: 5:30 PM',
      ],
      onSelected: (val) => setState(() => _eta = val),
    );
  }

  void _showSortByPicker() {
    _showOptionsPickerModal(
      title: 'Sort Recommendations By',
      currentSelection: _sortBy,
      options: const [
        'Sort: Best Match',
        'Sort: Lowest Price',
        'Sort: Shortest Walk',
        'Sort: Nearest Drive',
        'Sort: High Confidence',
      ],
      onSelected: (val) => setState(() => _sortBy = val),
    );
  }

  void _showFeatureFilterPicker() {
    _showOptionsPickerModal(
      title: 'Filter Carpark Features',
      currentSelection: _filterFeature,
      options: const [
        'Filter: All Carparks',
        'Filter: EV Charging',
        'Filter: Covered Only',
        'Filter: Height >= 1.9m',
        'Filter: Season Parking',
      ],
      onSelected: (val) => setState(() => _filterFeature = val),
    );
  }

  void _showOptionsPickerModal({
    required String title,
    required String currentSelection,
    required List<String> options,
    required ValueChanged<String> onSelected,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _cardColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: _mutedTextColor),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: options.length,
                  itemBuilder: (context, index) {
                    final option = options[index];
                    final isSelected = option == currentSelection;
                    return InkWell(
                      onTap: () {
                        onSelected(option);
                        Navigator.pop(ctx);
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 14),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? _accentColor.withValues(alpha: 0.15)
                              : _fieldColor,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isSelected
                                ? _accentColor.withValues(alpha: 0.5)
                                : const Color(0xFF2A2C34),
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              option,
                              style: TextStyle(
                                color: isSelected ? _accentColor : Colors.white,
                                fontSize: 14,
                                fontWeight: isSelected
                                    ? FontWeight.bold
                                    : FontWeight.w500,
                              ),
                            ),
                            if (isSelected)
                              const Icon(Icons.check_circle,
                                  color: _accentColor, size: 18),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildRecommendationsHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Top Recommendations',
              style: TextStyle(
                color: Colors.white,
                fontSize: 17,
                fontWeight: FontWeight.w600,
              ),
            ),
            // FR-5.2 Map View Segmented Switch
            Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                color: _fieldColor,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFF2A2C34)),
              ),
              child: Row(
                children: [
                  _buildSegmentedOption(
                    icon: Icons.format_list_bulleted,
                    label: 'List',
                    isSelected: !_isMapView,
                    onTap: () => setState(() => _isMapView = false),
                  ),
                  _buildSegmentedOption(
                    icon: Icons.map_outlined,
                    label: 'Map',
                    isSelected: _isMapView,
                    onTap: () => setState(() => _isMapView = true),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        // FR-3.6, NFR-SF4 Data Freshness / Indicative Notice
        Row(
          children: [
            FadeTransition(
              opacity: Tween<double>(begin: 0.2, end: 1.0).animate(
                CurvedAnimation(
                  parent: _blinkingController,
                  curve: Curves.easeInOut,
                ),
              ),
              child: const Icon(Icons.circle, color: _accentColor, size: 8),
            ),
            const SizedBox(width: 6),
            const Text(
              'Live Traffic',
              style: TextStyle(
                color: _accentColor,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Text(
              ' • ',
              style: TextStyle(color: _mutedTextColor, fontSize: 12),
            ),
            const Icon(Icons.history_toggle_off, color: _mutedTextColor, size: 13),
            const SizedBox(width: 4),
            const Text(
              'Updated 45s ago',
              style: TextStyle(
                color: _mutedTextColor,
                fontSize: 12,
                fontWeight: FontWeight.w400,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSegmentedOption({
    required IconData icon,
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(7),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: isSelected ? _accentColor : Colors.transparent,
          borderRadius: BorderRadius.circular(7),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              size: 14,
              color: isSelected ? Colors.black : _mutedTextColor,
            ),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: isSelected ? Colors.black : _mutedTextColor,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCarparkCard(_CarparkModel cp) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${cp.rank}. ${cp.name}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(
                          cp.driveTime,
                          style: const TextStyle(
                              color: _mutedTextColor, fontSize: 13),
                        ),
                        const Text(' • ',
                            style: TextStyle(
                                color: _mutedTextColor, fontSize: 13)),
                        Text(
                          cp.pricePerHour,
                          style: const TextStyle(
                            color: _greenColor,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // FR-4.8 Availability & Prediction Confidence Indicators
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _buildSpotsBadge(cp.spotsLeft, cp.spotsTotal),
                  const SizedBox(height: 6),
                  _buildConfidenceBadge(cp.confidenceLevel, cp.confidenceText),
                ],
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                cp.walkTime,
                style: const TextStyle(color: _mutedTextColor, fontSize: 12),
              ),
              // FR-3.6 Data Freshness indication per carpark card
              const Text(
                'Updated 45s ago',
                style: TextStyle(color: Color(0xFF6B7280), fontSize: 11),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                flex: 2,
                child: SizedBox(
                  height: 46,
                  child: ElevatedButton(
                    onPressed: () => _onParkHere(cp),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _accentColor,
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 0,
                    ),
                    child: const Text(
                      'Park Here',
                      style: TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 1,
                child: SizedBox(
                  height: 46,
                  child: OutlinedButton.icon(
                    onPressed: () {
                      // TODO: handle navigate action
                    },
                    icon: const Icon(Icons.navigation_outlined,
                        size: 16, color: Colors.white),
                    label: const Text(
                      'Go To',
                      style: TextStyle(color: Colors.white, fontSize: 13),
                    ),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFF2A2C34)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSpotsBadge(int left, int total) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF163634),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        '$left / $total left',
        style: const TextStyle(
          color: _greenColor,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  // FR-4.8 Prediction Confidence Badge
  Widget _buildConfidenceBadge(String level, String text) {
    final isHigh = level == 'High';
    final isMed = level == 'Medium';
    final badgeColor = isHigh
        ? _accentColor
        : isMed
            ? _amberColor
            : const Color(0xFFEF4444);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: badgeColor.withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: badgeColor.withOpacity(0.3), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isHigh ? Icons.verified_user_outlined : Icons.insights_outlined,
            color: badgeColor,
            size: 11,
          ),
          const SizedBox(width: 4),
          Text(
            text,
            style: TextStyle(
              color: badgeColor,
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // FR-5.2 Map View Placeholder UI
  Widget _buildMapViewPlaceholder() {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 16),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF2A2C34)),
      ),
      child: Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Container(
              color: const Color(0xFF12131A),
              child: CustomPaint(
                painter: _MockMapPainter(),
                child: const SizedBox.expand(),
              ),
            ),
          ),
          Positioned(
            top: 40,
            left: 40,
            child: _buildMapPin('1. Orchard Central', '\$4.50/hr', '48 left (High Conf)', _accentColor),
          ),
          Positioned(
            top: 130,
            right: 25,
            child: _buildMapPin('2. Suntec Plaza', '\$5.00/hr', '12 left (Med Conf)', _amberColor),
          ),
          Positioned(
            bottom: 70,
            left: 30,
            child: _buildMapPin('3. Somerset Underground', '\$3.80/hr', '142 left (High Conf)', _greenColor),
          ),
          Positioned(
            bottom: 130,
            right: 35,
            child: _buildMapPin('4. Marina Square', '\$4.00/hr', '85 left (High Conf)', _accentColor),
          ),
          Positioned(
            top: 220,
            left: 90,
            child: _buildMapPin('5. Ngee Ann City', '\$5.50/hr', '5 left (Low Conf)', const Color(0xFFEF4444)),
          ),
          // FR-3.6 Map View Data Freshness Overlay
          Positioned(
            top: 14,
            left: 14,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: _bgColor.withOpacity(0.85),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white12),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.history_toggle_off, color: _accentColor, size: 12),
                  SizedBox(width: 5),
                  Text(
                    'Updated 45s ago',
                    style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMapPin(String title, String price, String info, Color accentColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: _cardColor.withOpacity(0.95),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accentColor.withOpacity(0.6), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.location_on, color: accentColor, size: 18),
          const SizedBox(width: 6),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                title,
                style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
              ),
              Text(
                '$price • $info',
                style: TextStyle(color: _mutedTextColor, fontSize: 10, fontWeight: FontWeight.w500),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _onParkHere(_CarparkModel cp) {
    if (ParkingSessionManager.instance.hasActiveSession) {
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('A parking session is already ongoing.'),
          backgroundColor: Colors.redAccent,
          duration: Duration(seconds: 2),
        ),
      );
    } else {
      final rate = _parsePricePerHour(cp.pricePerHour);
      ParkingSessionManager.instance.startSession(
        carparkName: cp.name,
        location: 'Zone A, Lot 145',
        hourlyRate: rate,
      );
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          pageBuilder: (context, animation1, animation2) =>
              const ParkingSessionTrackerScreen(),
          transitionDuration: Duration.zero,
          reverseTransitionDuration: Duration.zero,
        ),
      );
    }
  }

  double _parsePricePerHour(String priceStr) {
    final clean = priceStr.replaceAll(RegExp(r'[^0-9.]'), '');
    return double.tryParse(clean) ?? 4.50;
  }

  void _onNavTap(int index) {
    if (index == _selectedNavIndex) return;
    Widget destination;
    switch (index) {
      case 0:
        destination = const CarparkSearchScreen();
        break;
      case 1:
        destination = const ParkingSessionTrackerScreen();
        break;
      case 2:
        destination = const PreferencesScreen();
        break;
      case 3:
        destination = const AdminPanelScreen();
        break;
      default:
        return;
    }
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation1, animation2) => destination,
        transitionDuration: Duration.zero,
        reverseTransitionDuration: Duration.zero,
      ),
    );
  }

  Widget _buildBottomNavBar() {
    final items = [
      (icon: Icons.search, label: 'Search'),
      (icon: Icons.show_chart, label: 'Tracker'),
      (icon: Icons.tune, label: 'Preferences'),
      (icon: Icons.chevron_right, label: 'Admin'),
    ];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        color: Color(0xFF0F1013),
        border: Border(top: BorderSide(color: Color(0xFF1E2027), width: 1)),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(items.length, (index) {
            final item = items[index];
            final isSelected = index == _selectedNavIndex;
            final color = isSelected ? _accentColor : _mutedTextColor;
            return InkWell(
              onTap: () => _onNavTap(index),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(item.icon, color: color, size: 22),
                  const SizedBox(height: 4),
                  Text(
                    item.label,
                    style: TextStyle(color: color, fontSize: 11),
                  ),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}

class _MockMapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1F212A)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;

    final path = Path();
    path.moveTo(0, size.height * 0.35);
    path.cubicTo(size.width * 0.3, size.height * 0.2, size.width * 0.6, size.height * 0.5, size.width, size.height * 0.45);

    path.moveTo(size.width * 0.25, 0);
    path.lineTo(size.width * 0.35, size.height);

    path.moveTo(size.width * 0.7, 0);
    path.cubicTo(size.width * 0.65, size.height * 0.4, size.width * 0.85, size.height * 0.7, size.width * 0.75, size.height);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
