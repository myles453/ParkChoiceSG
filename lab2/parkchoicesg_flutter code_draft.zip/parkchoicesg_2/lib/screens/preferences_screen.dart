import 'package:flutter/material.dart';
import 'admin_panel_screen.dart';
import 'carpark_search_screen.dart';
import 'parking_session_tracker_screen.dart';

/// ParkChoiceSG Preferences / Settings Screen
/// Drop this widget into a MaterialApp's `home` or push it via Navigator.
class PreferencesScreen extends StatefulWidget {
  const PreferencesScreen({super.key});

  @override
  State<PreferencesScreen> createState() => _PreferencesScreenState();
}

enum VehicleType { car, suvVan, lorry }

class _SavedDestinationModel {
  final String label;
  final String address;
  final IconData icon;
  final bool isCustom;

  const _SavedDestinationModel({
    required this.label,
    required this.address,
    required this.icon,
    this.isCustom = false,
  });
}

class _PreferencesScreenState extends State<PreferencesScreen> {
  static const _bgColor = Color(0xFF0B0B0F);
  static const _cardColor = Color(0xFF16171D);
  static const _pillColor = Color(0xFF1F2027);
  static const _accentColor = Color(0xFF22E1EE);
  static const _mutedTextColor = Color(0xFF8A8D98);
  static const _redColor = Color(0xFFEF4444);

  VehicleType _selectedVehicle = VehicleType.car;
  final int _selectedNavIndex = 2;

  // FR-1.3 Maximum Walking Distance Slider State (100m - 1000m, default 400m)
  double _maxWalkingDistance = 400;

  // FR-1.4 Ranking Criteria Priority Reordering State
  final List<String> _rankingCriteria = [
    'Cost',
    'Walking Distance',
    'Driving Time',
    'Availability Confidence',
  ];

  final Map<VehicleType, double> _clearanceByVehicle = const {
    VehicleType.car: 1.9,
    VehicleType.suvVan: 2.1,
    VehicleType.lorry: 3.5,
  };

  // FR-1.5 Saved Destinations State
  final List<_SavedDestinationModel> _savedDestinations = [
    const _SavedDestinationModel(
      label: 'Home',
      address: '82 Craig Road, Block B, Singapore',
      icon: Icons.home_outlined,
      isCustom: false,
    ),
    const _SavedDestinationModel(
      label: 'Work',
      address: 'One Raffles Quay, Level 44, Singapore',
      icon: Icons.work_outline,
      isCustom: false,
    ),
  ];

  String _vehicleLabel(VehicleType type) {
    switch (type) {
      case VehicleType.car:
        return 'Car';
      case VehicleType.suvVan:
        return 'SUV / Van';
      case VehicleType.lorry:
        return 'Lorry';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgColor,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildHeader(),
                    const SizedBox(height: 28),

                    // FR-1.5 Saved Destinations Section
                    const Text(
                      'Saved Destinations',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 12),
                    ..._savedDestinations.map(
                      (d) => Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _buildDestinationTile(d),
                      ),
                    ),
                    _buildAddLocationButton(),

                    const SizedBox(height: 28),

                    // Vehicle & Clearance Profile Section
                    const Text(
                      'Vehicle & Clearance Profile',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildVehicleClearanceCard(),

                    const SizedBox(height: 28),

                    // FR-1.3 Maximum Walking Distance Slider Section
                    const Text(
                      'Walking Tolerance',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildWalkingDistanceCard(),

                    const SizedBox(height: 28),

                    // FR-1.4 Ranking Criteria Priority Reordering Section
                    const Text(
                      'Ranking Criteria Priority',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Drag items to set recommendation priorities',
                      style: TextStyle(color: _mutedTextColor, fontSize: 13),
                    ),
                    const SizedBox(height: 12),
                    _buildRankingPriorityCard(),

                    const SizedBox(height: 32),

                    // FR-1.10 Data Management / Erase All Data Section
                    _buildEraseDataCard(),
                  ],
                ),
              ),
            ),
            _buildBottomNavBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        const Expanded(
          child: Text(
            'Preferences',
            style: TextStyle(
              color: Colors.white,
              fontSize: 26,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Container(
          width: 40,
          height: 40,
          decoration: const BoxDecoration(
            color: Color(0xFF1C2A33),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.person_outline, color: _accentColor, size: 20),
        ),
      ],
    );
  }

  Widget _buildDestinationTile(_SavedDestinationModel destination) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: _pillColor,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(destination.icon, color: _accentColor, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  destination.label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  destination.address,
                  style: const TextStyle(color: _mutedTextColor, fontSize: 12),
                ),
              ],
            ),
          ),
          if (destination.isCustom)
            IconButton(
              icon: const Icon(Icons.delete_outline, color: _redColor, size: 18),
              onPressed: () {
                setState(() {
                  _savedDestinations.remove(destination);
                });
              },
            )
          else
            IconButton(
              icon: const Icon(Icons.edit_outlined, color: _mutedTextColor, size: 18),
              onPressed: () {},
            ),
        ],
      ),
    );
  }

  // FR-1.5 Add Custom Location Button
  Widget _buildAddLocationButton() {
    return SizedBox(
      width: double.infinity,
      height: 46,
      child: OutlinedButton.icon(
        onPressed: _showAddLocationModal,
        icon: const Icon(Icons.add_location_alt_outlined, color: _accentColor, size: 18),
        label: const Text(
          '+ Add New Location',
          style: TextStyle(color: _accentColor, fontSize: 13, fontWeight: FontWeight.w600),
        ),
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: Color(0xFF2A2C34)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  void _showAddLocationModal() {
    final labelController = TextEditingController();
    final addressController = TextEditingController();

    showModalBottomSheet(
      context: context,
      backgroundColor: _cardColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.fromLTRB(
            24,
            24,
            24,
            MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Add Custom Location',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: _mutedTextColor),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              TextField(
                controller: labelController,
                style: const TextStyle(color: Colors.white, fontSize: 14),
                decoration: InputDecoration(
                  labelText: 'Location Label (e.g. Gym, Parents)',
                  labelStyle: const TextStyle(color: _mutedTextColor, fontSize: 13),
                  filled: true,
                  fillColor: _pillColor,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: addressController,
                style: const TextStyle(color: Colors.white, fontSize: 14),
                decoration: InputDecoration(
                  labelText: 'Address / Landmark',
                  labelStyle: const TextStyle(color: _mutedTextColor, fontSize: 13),
                  filled: true,
                  fillColor: _pillColor,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: () {
                    final label = labelController.text.trim();
                    final address = addressController.text.trim();
                    if (label.isNotEmpty && address.isNotEmpty) {
                      setState(() {
                        _savedDestinations.add(
                          _SavedDestinationModel(
                            label: label,
                            address: address,
                            icon: Icons.place_outlined,
                            isCustom: true,
                          ),
                        );
                      });
                    }
                    Navigator.pop(ctx);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _accentColor,
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'Save Location',
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildVehicleClearanceCard() {
    final clearance = _clearanceByVehicle[_selectedVehicle]!;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'ACTIVE VEHICLE TYPE',
            style: TextStyle(
              color: _mutedTextColor,
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 10),
          _buildVehicleSegmentedControl(),
          const SizedBox(height: 14),
          _buildClearanceNotice(clearance),
        ],
      ),
    );
  }

  Widget _buildVehicleSegmentedControl() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: _pillColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: VehicleType.values.map((type) {
          final isSelected = type == _selectedVehicle;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedVehicle = type),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: isSelected ? const Color(0xFF2A2C34) : null,
                  borderRadius: BorderRadius.circular(10),
                ),
                alignment: Alignment.center,
                child: Text(
                  _vehicleLabel(type),
                  style: TextStyle(
                    color: isSelected ? Colors.white : _mutedTextColor,
                    fontSize: 13,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildClearanceNotice(double clearance) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _pillColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: const BoxDecoration(
              color: Color(0xFF163634),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.warning_amber_rounded,
                color: _accentColor, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Assumed Clearance: ${clearance.toStringAsFixed(1)}m',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                const Text(
                  'Carparks below this height will be excluded automatically.',
                  style: TextStyle(color: _mutedTextColor, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // FR-1.3 Maximum Walking Distance Slider Card (100m - 1000m)
  Widget _buildWalkingDistanceCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'MAX WALKING DISTANCE',
                style: TextStyle(
                  color: _mutedTextColor,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF163634),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '${_maxWalkingDistance.toInt()} m',
                  style: const TextStyle(
                    color: _accentColor,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: _accentColor,
              inactiveTrackColor: _pillColor,
              thumbColor: _accentColor,
              overlayColor: _accentColor.withValues(alpha: 0.2),
              valueIndicatorTextStyle: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
            ),
            child: Slider(
              value: _maxWalkingDistance,
              min: 100,
              max: 1000,
              divisions: 18,
              label: '${_maxWalkingDistance.toInt()}m',
              onChanged: (val) {
                setState(() {
                  _maxWalkingDistance = val;
                });
              },
            ),
          ),
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('100m (Strict)', style: TextStyle(color: _mutedTextColor, fontSize: 11)),
              Text('1000m (Flexible)', style: TextStyle(color: _mutedTextColor, fontSize: 11)),
            ],
          ),
          const SizedBox(height: 10),
          const Text(
            'Recommendations further than this distance from your destination will be filtered out.',
            style: TextStyle(color: _mutedTextColor, fontSize: 12),
          ),
        ],
      ),
    );
  }

  // FR-1.4 Ranking Criteria Priority Reordering Card
  Widget _buildRankingPriorityCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: ReorderableListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _rankingCriteria.length,
        onReorder: (oldIndex, newIndex) {
          setState(() {
            if (oldIndex < newIndex) {
              newIndex -= 1;
            }
            final item = _rankingCriteria.removeAt(oldIndex);
            _rankingCriteria.insert(newIndex, item);
          });
        },
        itemBuilder: (context, index) {
          final item = _rankingCriteria[index];
          return Container(
            key: ValueKey(item),
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: _pillColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF262833)),
            ),
            child: Row(
              children: [
                Container(
                  width: 28,
                  height: 28,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: _accentColor.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '#${index + 1}',
                    style: const TextStyle(
                      color: _accentColor,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    item,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const Icon(Icons.drag_handle, color: _mutedTextColor, size: 20),
              ],
            ),
          );
        },
      ),
    );
  }

  // FR-1.10 Data Management / "Erase All Data" Section
  Widget _buildEraseDataCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF181214),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF3B1E22)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'DATA MANAGEMENT',
            style: TextStyle(
              color: _redColor,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Delete all locally stored preferences, search history, and saved locations.',
            style: TextStyle(color: _mutedTextColor, fontSize: 12),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            height: 46,
            child: OutlinedButton.icon(
              onPressed: _showEraseDataConfirmation,
              icon: const Icon(Icons.delete_forever_outlined, color: _redColor, size: 18),
              label: const Text(
                'Erase All Local Data',
                style: TextStyle(color: _redColor, fontSize: 13, fontWeight: FontWeight.bold),
              ),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Color(0xFF5C2329)),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showEraseDataConfirmation() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: Color(0xFF3B1E22)),
        ),
        title: const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: _redColor, size: 24),
            SizedBox(width: 8),
            Text(
              'Erase All Local Data?',
              style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'This will permanently delete your saved destinations, vehicle profiles, walking tolerance settings, search history, and local preferences.',
              style: TextStyle(color: _mutedTextColor, fontSize: 13),
            ),
            SizedBox(height: 12),
            Text(
              'This action cannot be undone.',
              style: TextStyle(color: _redColor, fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: _mutedTextColor)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              setState(() {
                _maxWalkingDistance = 400;
                _selectedVehicle = VehicleType.car;
              });
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('All local preferences and data have been erased.'),
                  backgroundColor: _redColor,
                  duration: Duration(seconds: 2),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _redColor,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text('Erase Data Now', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _onNavTap(int index) {
    if (index == _selectedNavIndex) return;
    Widget destination;
    switch (index) {
      case 0:
        destination = const CarparkSearchScreen();
        break;
      case 1:
        destination = const ParkingSessionTrackerScreen();
        break;
      case 2:
        destination = const PreferencesScreen();
        break;
      case 3:
        destination = const AdminPanelScreen();
        break;
      default:
        return;
    }
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation1, animation2) => destination,
        transitionDuration: Duration.zero,
        reverseTransitionDuration: Duration.zero,
      ),
    );
  }

  Widget _buildBottomNavBar() {
    final items = [
      (icon: Icons.search, label: 'Search'),
      (icon: Icons.show_chart, label: 'Tracker'),
      (icon: Icons.tune, label: 'Preferences'),
      (icon: Icons.chevron_right, label: 'Admin'),
    ];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        color: Color(0xFF0F1013),
        border: Border(top: BorderSide(color: Color(0xFF1E2027), width: 1)),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(items.length, (index) {
            final item = items[index];
            final isSelected = index == _selectedNavIndex;
            final color = isSelected ? _accentColor : _mutedTextColor;
            return InkWell(
              onTap: () => _onNavTap(index),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(item.icon, color: color, size: 22),
                  const SizedBox(height: 4),
                  Text(
                    item.label,
                    style: TextStyle(color: color, fontSize: 11),
                  ),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}
