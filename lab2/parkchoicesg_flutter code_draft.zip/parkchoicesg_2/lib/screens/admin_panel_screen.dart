import 'package:flutter/material.dart';
import 'carpark_search_screen.dart';
import 'parking_session_tracker_screen.dart';
import 'preferences_screen.dart';

/// ParkChoiceSG Admin Panel Screen
/// Drop this widget into a MaterialApp's `home` or push it via Navigator.
class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

enum AlertStatus { newAlert, inProgress, resolved }

class _AdminAlertModel {
  final String id;
  final String description;
  final AlertStatus status;

  const _AdminAlertModel({
    required this.id,
    required this.description,
    required this.status,
  });
}

// FR-4.3, FR-4.8, FR-8.4 Data Source Model
class _DataSourceModel {
  final String providerName;
  final String apiEndpoint;
  final bool isHealthy;
  final String uptime;
  final String requestVolume;
  final String failureCount;
  final String cacheAge;

  const _DataSourceModel({
    required this.providerName,
    required this.apiEndpoint,
    required this.isHealthy,
    required this.uptime,
    required this.requestVolume,
    required this.failureCount,
    required this.cacheAge,
  });
}

// FR-8.3, FR-8.5 Carpark Override Model
class _CarparkOverrideModel {
  final String carparkId;
  final String carparkName;
  final String overrideStatus;
  final String reason;
  final String appliedBy;

  const _CarparkOverrideModel({
    required this.carparkId,
    required this.carparkName,
    required this.overrideStatus,
    required this.reason,
    required this.appliedBy,
  });
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  static const _bgColor = Color(0xFF0B0B0F);
  static const _cardColor = Color(0xFF16171D);
  static const _pillColor = Color(0xFF1F2027);
  static const _accentColor = Color(0xFF22E1EE);
  static const _mutedTextColor = Color(0xFF8A8D98);
  static const _greenColor = Color(0xFF4ADE80);
  static const _orangeColor = Color(0xFFF5A623);
  static const _blueColor = Color(0xFF5B8DEF);
  static const _redColor = Color(0xFFEF4444);

  final int _selectedNavIndex = 3;

  final TextEditingController _carparkSearchController = TextEditingController();

  List<_AdminAlertModel> _alerts = const [
    _AdminAlertModel(
      id: 'R-8821',
      description: 'Barrier failure at Sector G exit gate',
      status: AlertStatus.newAlert,
    ),
    _AdminAlertModel(
      id: 'R-8819',
      description: 'API ingestion delay for Somerset Mall sensors',
      status: AlertStatus.inProgress,
    ),
    _AdminAlertModel(
      id: 'R-8814',
      description: 'Manual lot count discrepancy at Suntec plaza',
      status: AlertStatus.resolved,
    ),
  ];

  // FR-4.3, FR-4.8, FR-8.4 External Data Sources List
  final List<_DataSourceModel> _dataSources = [
    const _DataSourceModel(
      providerName: 'LTA DataMall API',
      apiEndpoint: 'datamall2.mytransport.sg/ltaodataservice',
      isHealthy: true,
      uptime: '99.9%',
      requestVolume: '4,280 req/min',
      failureCount: '0 (0.0%)',
      cacheAge: '14s ago',
    ),
    const _DataSourceModel(
      providerName: 'Data.gov.sg / HDB Api',
      apiEndpoint: 'api-open.data.gov.sg/v1/transport/carpark',
      isHealthy: true,
      uptime: '99.7%',
      requestVolume: '3,120 req/min',
      failureCount: '2 (0.06%)',
      cacheAge: '28s ago',
    ),
    const _DataSourceModel(
      providerName: 'URA Parking API',
      apiEndpoint: 'www.ura.gov.sg/uraServices/carpark',
      isHealthy: false,
      uptime: '94.5%',
      requestVolume: '1,450 req/min',
      failureCount: '18 (1.2%)',
      cacheAge: '52s ago (Stale)',
    ),
    const _DataSourceModel(
      providerName: 'OneMap & Navigation Services',
      apiEndpoint: 'developers.onemap.sg/commonapi',
      isHealthy: true,
      uptime: '99.9%',
      requestVolume: '890 req/min',
      failureCount: '0 (0.0%)',
      cacheAge: 'Live Direct',
    ),
  ];

  // FR-8.3, FR-8.5 Active Carpark Overrides List
  final List<_CarparkOverrideModel> _activeOverrides = [
    const _CarparkOverrideModel(
      carparkId: 'CP-0104',
      carparkName: 'Orchard Central Terminal',
      overrideStatus: 'CLOSED (Maintenance)',
      reason: 'Exit barrier sensor failure & tarmac repair',
      appliedBy: 'Op-Admin #42 • 2h ago',
    ),
    const _CarparkOverrideModel(
      carparkId: 'CP-0211',
      carparkName: 'Suntec Plaza Level B2',
      overrideStatus: 'FULL (Force Cap)',
      reason: 'VIP Event reserved zone',
      appliedBy: 'Op-Admin #12 • 4h ago',
    ),
  ];

  void _markResolved(String id) {
    setState(() {
      _alerts = _alerts
          .map((a) => a.id == id
              ? _AdminAlertModel(
                  id: a.id,
                  description: a.description,
                  status: AlertStatus.resolved,
                )
              : a)
          .toList();
    });
  }

  @override
  void dispose() {
    _carparkSearchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgColor,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildHeader(),
                    const SizedBox(height: 28),

                    // Active Admin Alerts Section
                    const Text(
                      'Active Admin Alerts',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 12),
                    ..._alerts.map(
                      (a) => Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _buildAlertCard(a),
                      ),
                    ),
                    const SizedBox(height: 24),

                    // FR-4.3, FR-4.8, FR-8.4 Per-Data-Source Breakdown
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: const [
                        Text(
                          'Per-Data-Source Health',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          '4 Gateway APIs',
                          style: TextStyle(color: _mutedTextColor, fontSize: 12),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ..._dataSources.map(
                      (ds) => Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _buildDataSourceCard(ds),
                      ),
                    ),
                    const SizedBox(height: 24),

                    // FR-8.3, FR-8.5 Carpark Override & Closure Section
                    const Text(
                      'Carpark Status Overrides & Closures',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Search carpark to apply manual closure or status override',
                      style: TextStyle(color: _mutedTextColor, fontSize: 12),
                    ),
                    const SizedBox(height: 12),
                    _buildCarparkOverrideSection(),
                  ],
                ),
              ),
            ),
            _buildBottomNavBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        const Expanded(
          child: Text(
            'Admin Panel',
            style: TextStyle(
              color: Colors.white,
              fontSize: 26,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Container(
          width: 40,
          height: 40,
          decoration: const BoxDecoration(
            color: Color(0xFF1C2A33),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.person_outline, color: _accentColor, size: 20),
        ),
      ],
    );
  }

  Widget _buildAlertCard(_AdminAlertModel alert) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                alert.id,
                style: const TextStyle(
                  color: _accentColor,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
              _buildStatusBadge(alert.status),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            alert.description,
            style: const TextStyle(color: Colors.white, fontSize: 14),
          ),
          if (alert.status != AlertStatus.resolved) ...[
            const SizedBox(height: 14),
            Align(
              alignment: Alignment.centerRight,
              child: SizedBox(
                height: 38,
                child: ElevatedButton(
                  onPressed: () => _markResolved(alert.id),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _accentColor,
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 0,
                  ),
                  child: const Text(
                    'Mark Resolved',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStatusBadge(AlertStatus status) {
    late final String label;
    late final Color color;
    late final Color bgColor;

    switch (status) {
      case AlertStatus.newAlert:
        label = 'NEW';
        color = _orangeColor;
        bgColor = const Color(0xFF3A2E17);
        break;
      case AlertStatus.inProgress:
        label = 'IN PROGRESS';
        color = _blueColor;
        bgColor = const Color(0xFF1E2A44);
        break;
      case AlertStatus.resolved:
        label = 'RESOLVED';
        color = _greenColor;
        bgColor = const Color(0xFF16332A);
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.3,
        ),
      ),
    );
  }

  // FR-4.3, FR-4.8, FR-8.4, FR-8.7 Data Source Card & Manual Refresh
  Widget _buildDataSourceCard(_DataSourceModel ds) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 10,
                height: 10,
                margin: const EdgeInsets.only(top: 4),
                decoration: BoxDecoration(
                  color: ds.isHealthy ? _greenColor : _orangeColor,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      ds.providerName,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      ds.apiEndpoint,
                      style: const TextStyle(color: _mutedTextColor, fontSize: 11),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              // FR-8.7 Manual Refresh Button per data source
              IconButton(
                icon: const Icon(Icons.sync, color: _accentColor, size: 20),
                tooltip: 'Trigger Manual Fetch',
                onPressed: () => _triggerDataFetch(ds.providerName),
              ),
            ],
          ),
          const SizedBox(height: 14),
          const Divider(color: Color(0xFF262833), height: 1),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _buildSourceMetric('REQ VOLUME', ds.requestVolume),
              ),
              Expanded(
                child: _buildSourceMetric('FAILURES', ds.failureCount,
                    isWarning: !ds.isHealthy),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _buildSourceMetric('CACHE AGE', ds.cacheAge),
              ),
              Expanded(
                child: _buildSourceMetric('UPTIME', ds.uptime,
                    color: ds.isHealthy ? _greenColor : _orangeColor),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSourceMetric(String label, String value,
      {bool isWarning = false, Color? color}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: _mutedTextColor,
            fontSize: 10,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.4,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          value,
          style: TextStyle(
            color: color ?? (isWarning ? _orangeColor : Colors.white),
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  void _triggerDataFetch(String providerName) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.sync, color: Colors.black, size: 18),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                'Manual fetch triggered for $providerName. Refreshing cache...',
                style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
        backgroundColor: _accentColor,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // FR-8.3, FR-8.5 Carpark Override Section
  Widget _buildCarparkOverrideSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Search & Select Carpark
          Row(
            children: [
              Expanded(
                child: Container(
                  height: 44,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: _pillColor,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: TextField(
                    controller: _carparkSearchController,
                    style: const TextStyle(color: Colors.white, fontSize: 13),
                    decoration: const InputDecoration(
                      hintText: 'Search carpark to override...',
                      hintStyle: TextStyle(color: _mutedTextColor, fontSize: 13),
                      border: InputBorder.none,
                      icon: Icon(Icons.search, color: _mutedTextColor, size: 18),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                height: 44,
                child: ElevatedButton(
                  onPressed: _showAddOverrideModal,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _accentColor,
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 0,
                  ),
                  child: const Text(
                    'Override',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text(
            'ACTIVE STATUS OVERRIDES',
            style: TextStyle(
              color: _mutedTextColor,
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 10),
          ..._activeOverrides.map((o) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _buildOverrideItemTile(o),
              )),
        ],
      ),
    );
  }

  Widget _buildOverrideItemTile(_CarparkOverrideModel overrideItem) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _pillColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF262833)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Text(
                  overrideItem.carparkName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _redColor.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _redColor.withValues(alpha: 0.3)),
                ),
                child: Text(
                  overrideItem.overrideStatus,
                  style: const TextStyle(
                    color: _redColor,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'Reason: ${overrideItem.reason}',
            style: const TextStyle(color: _mutedTextColor, fontSize: 12),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  overrideItem.appliedBy,
                  style: const TextStyle(color: Color(0xFF6B7280), fontSize: 11),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(width: 8),
              // FR-8.6 Withdraw Override Action
              InkWell(
                onTap: () {
                  setState(() {
                    _activeOverrides.remove(overrideItem);
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Override withdrawn for ${overrideItem.carparkName}'),
                      duration: const Duration(seconds: 2),
                    ),
                  );
                },
                child: const Text(
                  'Withdraw Override',
                  style: TextStyle(
                    color: _accentColor,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showAddOverrideModal() {
    String selectedCarpark = 'Orchard Central Terminal';
    String selectedStatus = 'CLOSED (Maintenance)';
    final reasonController = TextEditingController();

    showModalBottomSheet(
      context: context,
      backgroundColor: _cardColor,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.fromLTRB(
                24,
                24,
                24,
                MediaQuery.of(ctx).viewInsets.bottom + 24,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Apply Carpark Status Override',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, color: _mutedTextColor),
                        onPressed: () => Navigator.pop(ctx),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Text('Select Carpark:',
                      style: TextStyle(color: _mutedTextColor, fontSize: 12)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: _pillColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: selectedCarpark,
                        isExpanded: true,
                        dropdownColor: _pillColor,
                        style: const TextStyle(color: Colors.white, fontSize: 14),
                        items: [
                          'Orchard Central Terminal',
                          'Suntec Plaza Level B2',
                          'Somerset Underground',
                          'Marina Square Basement',
                          'Ngee Ann City Tower B'
                        ].map((cp) {
                          return DropdownMenuItem(value: cp, child: Text(cp));
                        }).toList(),
                        onChanged: (val) {
                          if (val != null) setModalState(() => selectedCarpark = val);
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text('Target Override Status:',
                      style: TextStyle(color: _mutedTextColor, fontSize: 12)),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: _pillColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: selectedStatus,
                        isExpanded: true,
                        dropdownColor: _pillColor,
                        style: const TextStyle(color: Colors.white, fontSize: 14),
                        items: [
                          'CLOSED (Maintenance)',
                          'FULL (Force Cap 0 Lots)',
                          'FORCE OPEN (Override Sensor)'
                        ].map((st) {
                          return DropdownMenuItem(value: st, child: Text(st));
                        }).toList(),
                        onChanged: (val) {
                          if (val != null) setModalState(() => selectedStatus = val);
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: reasonController,
                    style: const TextStyle(color: Colors.white, fontSize: 14),
                    decoration: InputDecoration(
                      labelText: 'Reason for Override (Audit Log)',
                      labelStyle: const TextStyle(color: _mutedTextColor, fontSize: 13),
                      filled: true,
                      fillColor: _pillColor,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton(
                      onPressed: () {
                        final reason = reasonController.text.trim();
                        setState(() {
                          _activeOverrides.insert(
                            0,
                            _CarparkOverrideModel(
                              carparkId: 'CP-${1000 + _activeOverrides.length}',
                              carparkName: selectedCarpark,
                              overrideStatus: selectedStatus,
                              reason: reason.isNotEmpty ? reason : 'Manual Operator Override',
                              appliedBy: 'Op-Admin #01 • Just now',
                            ),
                          );
                        });
                        Navigator.pop(ctx);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Applied override: $selectedStatus for $selectedCarpark'),
                            backgroundColor: _accentColor,
                            duration: const Duration(seconds: 2),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _accentColor,
                        foregroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'Apply Status Override',
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _onNavTap(int index) {
    if (index == _selectedNavIndex) return;
    Widget destination;
    switch (index) {
      case 0:
        destination = const CarparkSearchScreen();
        break;
      case 1:
        destination = const ParkingSessionTrackerScreen();
        break;
      case 2:
        destination = const PreferencesScreen();
        break;
      case 3:
        destination = const AdminPanelScreen();
        break;
      default:
        return;
    }
    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation1, animation2) => destination,
        transitionDuration: Duration.zero,
        reverseTransitionDuration: Duration.zero,
      ),
    );
  }

  Widget _buildBottomNavBar() {
    final items = [
      (icon: Icons.search, label: 'Search'),
      (icon: Icons.show_chart, label: 'Tracker'),
      (icon: Icons.tune, label: 'Preferences'),
      (icon: Icons.chevron_right, label: 'Admin'),
    ];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        color: Color(0xFF0F1013),
        border: Border(top: BorderSide(color: Color(0xFF1E2027), width: 1)),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(items.length, (index) {
            final item = items[index];
            final isSelected = index == _selectedNavIndex;
            final color = isSelected ? _accentColor : _mutedTextColor;
            return InkWell(
              onTap: () => _onNavTap(index),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(item.icon, color: color, size: 22),
                  const SizedBox(height: 4),
                  Text(
                    item.label,
                    style: TextStyle(color: color, fontSize: 11),
                  ),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}
