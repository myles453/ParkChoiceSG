import 'package:flutter/material.dart';

class CustomColor {
  static const Color darkGrey = Color.fromARGB(255, 50, 50, 50);
  static const Color lightGrey = Color.fromARGB(255, 240, 240, 240);
  static const Color neroGrey = Color.fromARGB(255, 15, 15, 15);
  static const Color denimBlue = Color.fromARGB(255, 25, 118, 211);
}